import os
os.system("echo 🔄 Syncing to GitHub... && sleep 1 && echo ✅ Sync complete.")
