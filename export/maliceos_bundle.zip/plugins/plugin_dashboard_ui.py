print("🧩 Dashboard UI placeholder — curses interface coming soon.")
